import React from 'react';

export default function Settings() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-4">Settings</h1>
      <p className="text-gray-400">User settings and configuration will be implemented here.</p>
    </div>
  );
}
